//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import cutout_native_plugin
import path_provider_foundation

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  CutoutNativePlugin.register(with: registry.registrar(forPlugin: "CutoutNativePlugin"))
  PathProviderPlugin.register(with: registry.registrar(forPlugin: "PathProviderPlugin"))
}
