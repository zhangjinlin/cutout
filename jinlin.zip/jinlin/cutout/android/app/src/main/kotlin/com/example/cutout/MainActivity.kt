package com.example.cutout

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
