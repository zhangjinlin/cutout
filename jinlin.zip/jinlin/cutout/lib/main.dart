import 'dart:io';

import 'package:flutter/material.dart';
import 'package:cutout_native_plugin/cutout_native_plugin.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '抠图Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: '抠图Demo'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String path = '';

  //点击抠图
  void _cutoutAction() async {
    var imgPath = await _saveImageToDevice('images/origin.png', 'origin');
    var maskPath = await _saveImageToDevice('images/mask.jpeg', 'mask');
    var text = await CutoutNativePlugin().getCutoutFilePath(imgPath, maskPath);
    print('结果:$text');
    path = text ?? '';

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Image.asset('images/origin.png', width: 300, height: 240),
          Image.asset('images/mask.jpeg', width: 300, height: 240),
          _cutoutWidget(),
        ],
      )),
      floatingActionButton: FloatingActionButton(
        onPressed: _cutoutAction,
        tooltip: 'Increment',
        child: Text('抠图'),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }

  Widget _cutoutWidget() {
    if (path.isNotEmpty) {
      return Image.file(File(path), width: 300, height: 240);
    } else {
      return Container();
    }
  }

  Future<String> _saveImageToDevice(String image, String name) async {
    final directory = await getApplicationDocumentsDirectory();
    final imagePath = directory.path + '/$name.png';
    final byteData = await rootBundle.load(image);
    final file = File(imagePath);
    await file.writeAsBytes(byteData.buffer.asUint8List());
    return imagePath;
  }
}
