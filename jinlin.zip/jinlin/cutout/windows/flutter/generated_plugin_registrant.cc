//
//  Generated file. Do not edit.
//

// clang-format off

#include "generated_plugin_registrant.h"

#include <cutout_native_plugin/cutout_native_plugin_c_api.h>

void RegisterPlugins(flutter::PluginRegistry* registry) {
  CutoutNativePluginCApiRegisterWithRegistrar(
      registry->GetRegistrarForPlugin("CutoutNativePluginCApi"));
}
