//
//  Generated file. Do not edit.
//

// clang-format off

#include "generated_plugin_registrant.h"

#include <cutout_native_plugin/cutout_native_plugin.h>

void fl_register_plugins(FlPluginRegistry* registry) {
  g_autoptr(FlPluginRegistrar) cutout_native_plugin_registrar =
      fl_plugin_registry_get_registrar_for_plugin(registry, "CutoutNativePlugin");
  cutout_native_plugin_register_with_registrar(cutout_native_plugin_registrar);
}
