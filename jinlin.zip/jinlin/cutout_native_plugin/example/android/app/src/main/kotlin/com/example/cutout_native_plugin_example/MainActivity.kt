package com.example.cutout_native_plugin_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
