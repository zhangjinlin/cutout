import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'cutout_native_plugin_platform_interface.dart';

/// An implementation of [CutoutNativePluginPlatform] that uses method channels.
class MethodChannelCutoutNativePlugin extends CutoutNativePluginPlatform {
  /// The method channel used to interact with the native platform.
  @visibleForTesting
  final methodChannel = const MethodChannel('cutout_native_plugin');

  @override
  Future<String?> getPlatformVersion() async {
    final version = await methodChannel.invokeMethod<String>('getPlatformVersion');
    return version;
  }

  //获取抠图后的路径
  @override
  Future<String?> getCutoutFilePath(Map<String, dynamic> arg) async {
    final path = await methodChannel.invokeMethod<String>('cutoutAction', arg);
    return path;
  }
}
