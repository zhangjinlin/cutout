import 'cutout_native_plugin_platform_interface.dart';

class CutoutNativePlugin {
  Future<String?> getPlatformVersion() {
    return CutoutNativePluginPlatform.instance.getPlatformVersion();
  }

  Future<String?> getCutoutFilePath(String imagePath, String maskPath) {
    var arg = {'imagePath': imagePath, 'maskPath': maskPath};
    return CutoutNativePluginPlatform.instance.getCutoutFilePath(arg);
  }
}
