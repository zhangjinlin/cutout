import 'package:plugin_platform_interface/plugin_platform_interface.dart';

import 'cutout_native_plugin_method_channel.dart';

abstract class CutoutNativePluginPlatform extends PlatformInterface {
  /// Constructs a CutoutNativePluginPlatform.
  CutoutNativePluginPlatform() : super(token: _token);

  static final Object _token = Object();

  static CutoutNativePluginPlatform _instance = MethodChannelCutoutNativePlugin();

  /// The default instance of [CutoutNativePluginPlatform] to use.
  ///
  /// Defaults to [MethodChannelCutoutNativePlugin].
  static CutoutNativePluginPlatform get instance => _instance;

  /// Platform-specific implementations should set this with their own
  /// platform-specific class that extends [CutoutNativePluginPlatform] when
  /// they register themselves.
  static set instance(CutoutNativePluginPlatform instance) {
    PlatformInterface.verifyToken(instance, _token);
    _instance = instance;
  }

  Future<String?> getPlatformVersion() {
    throw UnimplementedError('platformVersion() has not been implemented.');
  }

    Future<String?> getCutoutFilePath(Map<String, dynamic> arg) {
    throw UnimplementedError('platformVersion() has not been implemented.');
  }
}
