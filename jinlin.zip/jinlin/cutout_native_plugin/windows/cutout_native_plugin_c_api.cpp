#include "include/cutout_native_plugin/cutout_native_plugin_c_api.h"

#include <flutter/plugin_registrar_windows.h>

#include "cutout_native_plugin.h"

void CutoutNativePluginCApiRegisterWithRegistrar(
    FlutterDesktopPluginRegistrarRef registrar) {
  cutout_native_plugin::CutoutNativePlugin::RegisterWithRegistrar(
      flutter::PluginRegistrarManager::GetInstance()
          ->GetRegistrar<flutter::PluginRegistrarWindows>(registrar));
}
