import Flutter
import UIKit

public class CutoutNativePlugin: NSObject, FlutterPlugin {
  public static func register(with registrar: FlutterPluginRegistrar) {
    let channel = FlutterMethodChannel(name: "cutout_native_plugin", binaryMessenger: registrar.messenger())
    let instance = CutoutNativePlugin()
    registrar.addMethodCallDelegate(instance, channel: channel)
  }

  public func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
    switch call.method {
    case "getPlatformVersion": 
     result("iOS " + UIDevice.current.systemVersion)
    case "cutoutAction":
    if let args = call.arguments as? [String: Any], let imagePath = args["imagePath"] as? String , let maskPath = args["maskPath"] as? String {
   
   if let imageImg = loadPhoto(imagePath: imagePath),let maskImg = loadPhoto(imagePath: maskPath) {
       if  let img = PhotoManager.cutout(originImg: imageImg, maskImg: maskImg) {
          var path = PhotoManager.saveImage(img: img)
          if path.hasPrefix("file://") {
              path = path.replacingOccurrences(of: "file://", with: "")
           } 
          result(path)
         } else {
        // print("抠图失败")
      }
      } else {
        // print("没有读取到图片")
      }
    }

    result("")

    default:
      result(FlutterMethodNotImplemented)
    }
  }

   func loadPhoto( imagePath: String) -> UIImage?{
       return UIImage(contentsOfFile: imagePath)
   }
}
