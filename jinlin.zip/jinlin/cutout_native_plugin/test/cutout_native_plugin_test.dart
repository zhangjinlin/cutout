import 'package:flutter_test/flutter_test.dart';
import 'package:cutout_native_plugin/cutout_native_plugin.dart';
import 'package:cutout_native_plugin/cutout_native_plugin_platform_interface.dart';
import 'package:cutout_native_plugin/cutout_native_plugin_method_channel.dart';
import 'package:plugin_platform_interface/plugin_platform_interface.dart';

class MockCutoutNativePluginPlatform
    with MockPlatformInterfaceMixin
    implements CutoutNativePluginPlatform {

  @override
  Future<String?> getPlatformVersion() => Future.value('42');
}

void main() {
  final CutoutNativePluginPlatform initialPlatform = CutoutNativePluginPlatform.instance;

  test('$MethodChannelCutoutNativePlugin is the default instance', () {
    expect(initialPlatform, isInstanceOf<MethodChannelCutoutNativePlugin>());
  });

  test('getPlatformVersion', () async {
    CutoutNativePlugin cutoutNativePlugin = CutoutNativePlugin();
    MockCutoutNativePluginPlatform fakePlatform = MockCutoutNativePluginPlatform();
    CutoutNativePluginPlatform.instance = fakePlatform;

    expect(await cutoutNativePlugin.getPlatformVersion(), '42');
  });
}
